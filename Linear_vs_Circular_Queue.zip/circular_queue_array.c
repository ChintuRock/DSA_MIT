#include <stdio.h>
#include "queue.h"

struct Student queue[MAX];

int front = -1;
int rear = -1;


// Add student - ENQUEUE
void addStudent_261100690007(struct Student s)
{
    /*
       Circular queue is full when:
       (rear + 1) % MAX == front
    */
    if ((rear + 1) % MAX == front)
    {
        printf("Queue is full. Cannot add student.\n");
        return;
    }

    // If queue is empty
    if (front == -1)
    {
        front = 0;
        rear = 0;
    }
    else
    {
        // Move rear circularly
        rear = (rear + 1) % MAX;
    }

    queue[rear] = s;

    printf("Student added successfully.\n");
}


// Remove student - DEQUEUE
void removeStudent_261100690007(void)
{
    if (front == -1)
    {
        printf("No student to remove.\n");
        return;
    }

    printf("\nRemoved Student:\n");
    printf("Roll No : %d\n", queue[front].rollNo);
    printf("Name    : %s\n", queue[front].name);
    printf("Course  : %s\n", queue[front].course);
    printf("Marks   : %.2f\n", queue[front].marks);


    // If there is only one student
    if (front == rear)
    {
        front = -1;
        rear = -1;
    }
    else
    {
        // Move front circularly
        front = (front + 1) % MAX;
    }
}


// Peek - view front student without deleting
void peekStudent_261100690007(void)
{
    if (front == -1)
    {
        printf("Queue is empty.\n");
        return;
    }

    printf("\nFRONT STUDENT\n");
    printf("Roll No : %d\n", queue[front].rollNo);
    printf("Name    : %s\n", queue[front].name);
    printf("Course  : %s\n", queue[front].course);
    printf("Marks   : %.2f\n", queue[front].marks);
}



// Display all students
void displayStudents_261100690007(void)
{
    int i;

    if (front == -1)
    {
        printf("Queue is empty.\n");
        return;
    }

    printf("\n===== STUDENTS IN CIRCULAR QUEUE =====\n");
    i = front;
    while (1)
    {
        printf("\nRoll No : %d\n", queue[i].rollNo);
        printf("Name    : %s\n", queue[i].name);
        printf("Course  : %s\n", queue[i].course);
        printf("Marks   : %.2f\n", queue[i].marks);
        if (i == rear)
        {
            break;
        }
        i = (i + 1) % MAX;
    }
}
