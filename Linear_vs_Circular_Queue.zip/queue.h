#ifndef QUEUE_H_INCLUDED
#define QUEUE_H_INCLUDED


#define MAX 3

struct Student
{
    int rollNo;
    char name[50];
    char course[50];
    float marks;
};

void addStudent_261100690007(struct Student s);
void removeStudent_261100690007(void);
void peekStudent_261100690007(void);
void displayStudents_261100690007(void);


#endif // QUEUE_H_INCLUDED

