#include <stdio.h>
#include "queue.h"

struct Student queue[MAX];

int front = -1;
int rear = -1;

// Add student, ENQUEUE
void addStudent_261100690007(struct Student s)
{
    if (rear == MAX - 1)
    {
        printf("Cannot add student\n");
        return;
    }
    if (front == -1)
    {
        front = 0;
    }
    rear++;
    queue[rear] = s;

    printf("Student added successfully\n");
}

// Delete student, DEQUEUE
void removeStudent_261100690007(void)
{
    if (front == -1 || front > rear)
    {
        printf("No student to remove\n");
        return;
    }

    printf("\nRemoved Student:\n");
    printf("Roll No : %d\n", queue[front].rollNo);
    printf("Name    : %s\n", queue[front].name);
    printf("Course  : %s\n", queue[front].course);
    printf("Marks   : %.2f\n", queue[front].marks);

    front++;

    if (front > rear)
    {
        front = -1;
        rear = -1;
    }
}

// Peek, view front student without deleting
void peekStudent_261100690007(void)
{
    if (front == -1)
    {
        printf("Queue is empty\n");
        return;
    }

    printf("\nFRONT STUDENT\n");
    printf("Roll No : %d\n", queue[front].rollNo);
    printf("Name    : %s\n", queue[front].name);
    printf("Course  : %s\n", queue[front].course);
    printf("Marks   : %.2f\n", queue[front].marks);
}



// Display all students
void displayStudents_261100690007(void)
{
    int i;

    if (front == -1)
    {
        printf("Queue is empty.\n");
        return;
    }

    printf("\n===== STUDENTS IN QUEUE =====\n");

    for (i = front; i <= rear; i++)
    {
        printf("\nRoll No : %d\n", queue[i].rollNo);
        printf("Name    : %s\n", queue[i].name);
        printf("Course  : %s\n", queue[i].course);
        printf("Marks   : %.2f\n", queue[i].marks);
    }
}
