#include <stdio.h>
#include "queue.h"

int main()
{
    int choice;
    int rollNo;

    struct Student s;

    do
    {
        printf("\nSTUDENT QUEUE MANAGEMENT\n");
        printf("1. Add Student\n");
        printf("2. Remove Student\n");
        printf("3. Peek Student\n");
        printf("4. Display Students\n");
        printf("5. Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                printf("Enter Roll No: ");
                scanf("%d", &s.rollNo);

                printf("Enter Name: ");
                scanf(" %49[^\n]", s.name);

                printf("Enter Course: ");
                scanf(" %49[^\n]", s.course);

                printf("Enter Marks: ");
                scanf("%f", &s.marks);

                addStudent_261100690007(s);
                break;

            case 2:
                removeStudent_261100690007();
                break;

            case 3:
                peekStudent_261100690007();
                break;

            case 4:
                displayStudents_261100690007();
                break;

            case 5:
                printf("Exiting program...\n");
                break;

            default:
                printf("Invalid choice!\n");
        }

    } while (choice != 5);

    return 0;
}
