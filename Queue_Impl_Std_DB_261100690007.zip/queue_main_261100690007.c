#include <stdio.h>
#include "queue.h"

int main()
{
    int choice;
    int rollNo;

    struct Student s;

    do
    {
        printf("\nSTUDENT QUEUE MANAGEMENT\n");
        printf("1. Add Student\n");
        printf("2. Remove Student\n");
        printf("3. Peek Student\n");
        printf("4. Find Student\n");
        printf("5. Update Student\n");
        printf("6. Display Students\n");
        printf("7. Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                printf("Enter Roll No: ");
                scanf("%d", &s.rollNo);

                printf("Enter Name: ");
                scanf(" %49[^\n]", s.name);

                printf("Enter Course: ");
                scanf(" %49[^\n]", s.course);

                printf("Enter Marks: ");
                scanf("%f", &s.marks);

                addStudent(s);
                break;

            case 2:
                removeStudent();
                break;

            case 3:
                peekStudent();
                break;

            case 4:
                printf("Enter Roll No to find: ");
                scanf("%d", &rollNo);

                findStudent(rollNo);
                break;

            case 5:
                printf("Enter Roll No to update: ");
                scanf("%d", &rollNo);

                updateStudent(rollNo);
                break;

            case 6:
                displayStudents();
                break;

            case 7:
                printf("Exiting program...\n");
                break;

            default:
                printf("Invalid choice!\n");
        }

    } while (choice != 7);

    return 0;
}
