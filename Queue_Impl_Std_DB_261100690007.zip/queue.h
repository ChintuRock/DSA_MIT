#ifndef QUEUE_H_INCLUDED
#define QUEUE_H_INCLUDED


#define MAX 100

struct Student
{
    int rollNo;
    char name[50];
    char course[50];
    float marks;
};

void addStudent(struct Student s);
void removeStudent(void);
void peekStudent(void);
void findStudent(int rollNo);
void updateStudent(int rollNo);
void displayStudents(void);


#endif // QUEUE_H_INCLUDED
