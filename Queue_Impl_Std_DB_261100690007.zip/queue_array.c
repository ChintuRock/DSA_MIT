#include <stdio.h>
#include "queue.h"

struct Student queue[MAX];

int front = -1;
int rear = -1;

// Add student, ENQUEUE
void addStudent(struct Student s)
{
    if (rear == MAX - 1)
    {
        printf("Cannot add student\n");
        return;
    }

    if (front == -1)
    {
        front = 0;
    }

    rear++;
    queue[rear] = s;

    printf("Student added successfully\n");
}

// Delete student, DEQUEUE
void removeStudent(void)
{
    if (front == -1 || front > rear)
    {
        printf("No student to remove\n");
        return;
    }

    printf("\nRemoved Student:\n");
    printf("Roll No : %d\n", queue[front].rollNo);
    printf("Name    : %s\n", queue[front].name);
    printf("Course  : %s\n", queue[front].course);
    printf("Marks   : %.2f\n", queue[front].marks);

    front++;

    if (front > rear)
    {
        front = -1;
        rear = -1;
    }
}

// Peek, view front student without deleting
void peekStudent(void)
{
    if (front == -1)
    {
        printf("Queue is empty\n");
        return;
    }

    printf("\nFRONT STUDENT\n");
    printf("Roll No : %d\n", queue[front].rollNo);
    printf("Name    : %s\n", queue[front].name);
    printf("Course  : %s\n", queue[front].course);
    printf("Marks   : %.2f\n", queue[front].marks);
}

// Find student
void findStudent(int rollNo)
{
    int i;

    if (front == -1)
    {
        printf("Queue is empty.\n");
        return;
    }

    for (i = front; i <= rear; i++)
    {
        if (queue[i].rollNo == rollNo)
        {
            printf("\nSTUDENT FOUND\n");
            printf("Roll No : %d\n", queue[i].rollNo);
            printf("Name    : %s\n", queue[i].name);
            printf("Course  : %s\n", queue[i].course);
            printf("Marks   : %.2f\n", queue[i].marks);

            return;
        }
    }

    printf("Student not found\n");
}

// Update student
void updateStudent(int rollNo)
{
    int i;

    for (i = front; i <= rear; i++)
    {
        if (queue[i].rollNo == rollNo)
        {
            printf("Enter new name: ");
            scanf(" %49[^\n]", queue[i].name);

            printf("Enter new course: ");
            scanf(" %49[^\n]", queue[i].course);

            printf("Enter new marks: ");
            scanf("%f", &queue[i].marks);

            printf("Student record updated successfully.\n");

            return;
        }
    }

    printf("Student not found.\n");
}

// Display all students
void displayStudents(void)
{
    int i;

    if (front == -1)
    {
        printf("Queue is empty.\n");
        return;
    }

    printf("\n===== STUDENTS IN QUEUE =====\n");

    for (i = front; i <= rear; i++)
    {
        printf("\nRoll No : %d\n", queue[i].rollNo);
        printf("Name    : %s\n", queue[i].name);
        printf("Course  : %s\n", queue[i].course);
        printf("Marks   : %.2f\n", queue[i].marks);
    }
}
