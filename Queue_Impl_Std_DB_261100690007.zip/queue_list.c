#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

struct Node
{
    struct Student data;
    struct Node *next;
};

struct Node *front = NULL;
struct Node *rear = NULL;

// Add student, ENQUEUE
void addStudent(struct Student s)
{
    struct Node *newNode;

    newNode = (struct Node *)malloc(sizeof(struct Node));

    if (newNode == NULL)
    {
        printf("Memory allocation failed\n");
        return;
    }

    newNode->data = s;
    newNode->next = NULL;

    if (rear == NULL)
    {
        front = rear = newNode;
    }
    else
    {
        rear->next = newNode;
        rear = newNode;
    }

    printf("Student added successfully\n");
}

// Delete student, DEQUEUE
void removeStudent(void)
{
    struct Node *temp;

    if (front == NULL)
    {
        printf("No student to remove\n");
        return;
    }

    temp = front;

    printf("\nRemoved Student:\n");
    printf("Roll No : %d\n", temp->data.rollNo);
    printf("Name    : %s\n", temp->data.name);
    printf("Course  : %s\n", temp->data.course);
    printf("Marks   : %.2f\n", temp->data.marks);

    front = front->next;

    if (front == NULL)
    {
        rear = NULL;
    }

    free(temp);
}

// Peek, view front student without deleting
void peekStudent(void)
{
    if (front == NULL)
    {
        printf("Queue is empty\n");
        return;
    }

    printf("\nFRONT STUDENT\n");
    printf("Roll No : %d\n", front->data.rollNo);
    printf("Name    : %s\n", front->data.name);
    printf("Course  : %s\n", front->data.course);
    printf("Marks   : %.2f\n", front->data.marks);
}

// Find student
void findStudent(int rollNo)
{
    struct Node *temp = front;

    while (temp != NULL)
    {
        if (temp->data.rollNo == rollNo)
        {
            printf("\nSTUDENT FOUND\n");
            printf("Roll No : %d\n", temp->data.rollNo);
            printf("Name    : %s\n", temp->data.name);
            printf("Course  : %s\n", temp->data.course);
            printf("Marks   : %.2f\n", temp->data.marks);

            return;
        }

        temp = temp->next;
    }

    printf("Student not found.\n");
}

// Update student
void updateStudent(int rollNo)
{
    struct Node *temp = front;

    while (temp != NULL)
    {
        if (temp->data.rollNo == rollNo)
        {
            printf("Enter new name: ");
            scanf(" %49[^\n]", temp->data.name);

            printf("Enter new course: ");
            scanf(" %49[^\n]", temp->data.course);

            printf("Enter new marks: ");
            scanf("%f", &temp->data.marks);

            printf("Student record updated successfully\n");

            return;
        }

        temp = temp->next;
    }

    printf("Student not found.\n");
}

// Display all students
void displayStudents(void)
{
    struct Node *temp = front;

    if (front == NULL)
    {
        printf("Queue is empty.\n");
        return;
    }

    printf("\nSTUDENTS IN QUEUE\n");

    while (temp != NULL)
    {
        printf("\nRoll No : %d\n", temp->data.rollNo);
        printf("Name    : %s\n", temp->data.name);
        printf("Course  : %s\n", temp->data.course);
        printf("Marks   : %.2f\n", temp->data.marks);

        temp = temp->next;
    }
}
