#!/usr/bin/bash

#question1 Failed login alerts 
if [$# -eq "0"];then
	echo "No arguments entered"
	exit 1
fi

filenm=$1
threshold=$2


if [!-e "$filenm"];then
	echo "File does not exist"
	exit 1
fi

if [! -r "$filenm"];then
	echo "File is not readable"
	exit 1
fi


grep -c 'login_failed' "$filenm" >> login_report.log
grep -n 'login_failed' "$filenm" >> login_report.log

echo "$threshold" >> login_report.log
ls -lrt "$filenm" >> login_report.log

if [ grep -c 'login_failed' "$filenm" >= "$threshold" ];then
	echo "ALERT: Failed login threshold reached" >> login_report.log
else
	echo "ailed login count is below the threshold." >> login_report.log
fi
	
