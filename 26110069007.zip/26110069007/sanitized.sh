#!/usr/bin/bash

#filenm=$1

sed -n '/login_failed/p' authentication.log
sed -En '/WARN|ERROR/p' authentication.log
sed -n '2,4p' authentication.log
sed -n '/INFO/!p' authentication.log
sed '/INFO/d' authentication.log
sed -E 's/192\.0\.2\.[0-9]{2}/MASKED/g' authentication.log >> authentication_sanitized.log
egrep 'alice|bob|admin' authentication.log | sed -E 's/alice|bob|admin/REDACTED/g' >> authentication_sanitized.log
