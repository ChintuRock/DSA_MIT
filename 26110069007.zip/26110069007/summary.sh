#!/usr/bin/bash

filenm=$1
whoami >>authentication_report.txt
ls -lrt "$filenm" >>authentication_report.txt
wc -l "$filenm" >>authentication_report.txt
grep -c 'login_success' "$filenm" >>authentication_report.txt
grep -c 'login_failed' "$filenm" >>authentication_report.txt
grep -c 'access_denied' "$filenm" >>authentication_report.txt
grep -c 'logout' "$filenm" >>authentication_report.txt 
