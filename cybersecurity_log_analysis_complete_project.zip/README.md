# Cybersecurity Log Analysis Using Linux Tools

## Scenario
Offline investigation of SSH authentication events on a fictional Linux lab server. The supplied `data/auth.log` is a synthetic teaching dataset. It contains no real credentials, real user records, or real system data. Documentation-only IP ranges (RFC 5737) are used for external-looking addresses.

## Requirements
- Linux, WSL, or macOS terminal with Bash, `grep`, `sed`, `awk`, `sort`, `uniq`, `head`, and `wc`.
- No network access, scanning, or privileged access is required.

## Run
From the project directory:

```bash
chmod +x scripts/analyze_auth_logs.sh
./scripts/analyze_auth_logs.sh
```

Optional custom input and output paths:

```bash
./scripts/analyze_auth_logs.sh /path/to/auth.log /path/to/output
```

## Generated files
- `output/summary.txt` – overall findings and suspicious sources.
- `output/failed_attempts.txt` – failed SSH authentication records.
- `output/successful_logins.txt` – accepted password/public-key records.
- `output/failed_by_ip.txt` – failed-attempt counts per source IP.
- `output/suspicious_ips.txt` – sources meeting the configured threshold.
- `output/normalized_failed.txt` – whitespace-normalized failed records.

## Detection rule
A source is flagged when it produces **5 or more failed authentication events** in this sample. This is a simple triage threshold, not proof of compromise. A real deployment should use time-windowed rates, asset criticality, allowlists, geolocation/context where lawful, and correlation with other telemetry.

## Dataset provenance
- Dataset name: Synthetic SSH authentication log (created for this assignment).
- Source URL: Not applicable; generated locally for safe classroom simulation.
- Creation/access date: 05 November 2026.
- Scenario environment: Fictional isolated lab-server log; no live host was accessed.

## Tool usage
- `grep -E`: filters failed and successful SSH authentication lines.
- `sed -E`: normalizes repeated whitespace in failed records.
- `awk`: extracts the IP following the word `from`, counts events, and applies the threshold.
- `sort -nr`: sorts counts numerically in descending order.
- `wc -l`: counts records.
- `head -n 5`: displays the five highest counts.
- Bash variables, conditionals, redirection, and a grouped output block orchestrate the workflow.

## Safety
This project is an offline analysis of a synthetic log. Do not run scans or tests against public, institutional, or third-party systems. Do not insert passwords, tokens, or personal data into logs.

## Academic integrity / assistance disclosure
The sample dataset, script structure, and report draft were prepared with AI assistance. Review, run, understand, and adapt the work before submission, and disclose assistance according to the instructor's rules.
