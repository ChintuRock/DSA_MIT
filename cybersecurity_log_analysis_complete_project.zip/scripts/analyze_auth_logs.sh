#!/usr/bin/env bash
# SSH authentication log analyzer - safe, offline analysis of supplied sample.
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
LOG_FILE="${1:-$PROJECT_DIR/data/auth.log}"
OUT_DIR="${2:-$PROJECT_DIR/output}"

if [[ ! -f "$LOG_FILE" ]]; then
  echo "ERROR: Log file not found: $LOG_FILE" >&2
  exit 1
fi
mkdir -p "$OUT_DIR"

SUMMARY="$OUT_DIR/summary.txt"
FAILED="$OUT_DIR/failed_attempts.txt"
SUCCESS="$OUT_DIR/successful_logins.txt"
IP_COUNTS="$OUT_DIR/failed_by_ip.txt"
SUSPICIOUS="$OUT_DIR/suspicious_ips.txt"
NORMALIZED="$OUT_DIR/normalized_failed.txt"

# Power filters / pipelines equivalent on Linux: grep, cut, sort, uniq, head.
grep -E 'Failed password' "$LOG_FILE" > "$FAILED" || true
grep -E 'Accepted (password|publickey)' "$LOG_FILE" > "$SUCCESS" || true

# sed: normalize syslog whitespace and retain only failed-authentication records.
sed -E 's/[[:space:]]+/ /g' "$FAILED" > "$NORMALIZED"

# awk: extract source IP and count failed attempts per source.
awk '
  /Failed password/ {
    for (i=1; i<=NF; i++) {
      if ($i == "from" && (i+1) <= NF) {
        ip=$(i+1); count[ip]++
      }
    }
  }
  END {
    for (ip in count) print count[ip], ip
  }
' "$NORMALIZED" | sort -nr > "$IP_COUNTS"

# Threshold: 5 or more failed attempts from one source in this sample.
awk '$1 >= 5 { print $2 " (" $1 " failed attempts)" }' "$IP_COUNTS" > "$SUSPICIOUS"

TOTAL="$(wc -l < "$LOG_FILE" | tr -d ' ')"
FAIL_COUNT="$(wc -l < "$FAILED" | tr -d ' ')"
SUCCESS_COUNT="$(wc -l < "$SUCCESS" | tr -d ' ')"
UNIQUE_FAILED_IPS="$(awk '{print $2}' "$IP_COUNTS" | wc -l | tr -d ' ')"

{
  echo "SSH AUTHENTICATION LOG ANALYSIS"
  echo "================================"
  echo "Input log: $LOG_FILE"
  echo "Total records: $TOTAL"
  echo "Failed authentication records: $FAIL_COUNT"
  echo "Successful authentication records: $SUCCESS_COUNT"
  echo "Unique source IPs with failures: $UNIQUE_FAILED_IPS"
  echo
  echo "Failed attempts by source IP (descending):"
  if [[ -s "$IP_COUNTS" ]]; then cat "$IP_COUNTS"; else echo "None"; fi
  echo
  echo "Potentially suspicious sources (threshold >= 5 failures):"
  if [[ -s "$SUSPICIOUS" ]]; then cat "$SUSPICIOUS"; else echo "None"; fi
  echo
  echo "Top 5 source IPs by failed attempts:"
  if [[ -s "$IP_COUNTS" ]]; then head -n 5 "$IP_COUNTS"; else echo "None"; fi
} > "$SUMMARY"

echo "Analysis complete."
echo "Summary: $SUMMARY"
echo "Failed records: $FAILED"
echo "Successful records: $SUCCESS"
echo "Per-IP counts: $IP_COUNTS"
echo "Suspicious sources: $SUSPICIOUS"
