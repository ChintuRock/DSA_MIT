# Usage: awk -f scripts/count_failed_by_ip.awk output/normalized_failed.txt
/Failed password/ {
  for (i=1; i<=NF; i++) {
    if ($i == "from" && (i+1) <= NF) count[$(i+1)]++
  }
}
END {
  for (ip in count) print count[ip], ip
}
