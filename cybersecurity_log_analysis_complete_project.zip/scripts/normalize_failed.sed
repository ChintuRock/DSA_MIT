# Usage: sed -E -f scripts/normalize_failed.sed output/failed_attempts.txt
s/[[:space:]]+/ /g
