#ifndef TOH_HEADER_H_INCLUDED
#define TOH_HEADER_H_INCLUDED

void towerOfHanoi(int n, char from, char to, char aux);
int gcd_brute_force(int a, int b);
int gcd_recursive(int a, int b);


#endif // TOH_HEADER_H_INCLUDED
