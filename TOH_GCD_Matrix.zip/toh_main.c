#include <stdio.h>
#include "toh_header.h"

// implementation of Tower of Hanoi
void towerOfHanoi_261100690007(int n, char from, char to, char aux)
{
    if (n == 1)
    {
        printf("\n Move disk 1 from rod %c to rod %c", from, to);
        return;
    }
    towerOfHanoi_261100690007(n-1, from, aux, to);
    printf("\n Move disk %d from rod %c to rod %c", n, from, to);
    towerOfHanoi_261100690007(n-1, aux, to, from);
}


// GCD of two numbers using brute force method
int gcd_brute_force_261100690007(int a, int b)
{
    // If either number is 0, the GCD is the other number
    if (a == 0) return b;
    if (b == 0) return a;

    // Find the minimum of the two numbers
    int min = (a < b) ? a : b;

    // Check from min to 1
    for (int i = min; i >= 1; i--)
    {
        if (a % i == 0 && b % i == 0)
        {
            return i; // The first common divisor found from the top is the GCD
        }
    }
    return 1;
}


// GCD of 2 numbers using recursion
int gcd_recursive_261100690007(int a, int b) {
    // Base case: if the second number becomes 0, the first is the GCD
    if (b == 0) {
        return a;
    }
    // Recursive case
    return gcd_recursive_261100690007(b, a % b);
}



void addition_of_matrix()
{
    int r, c, a[100][100], b[100][100], sum[100][100], i, j;
  printf("Enter the number of rows : ");
  scanf("%d", &r);
  printf("Enter the number of columns : ");
  scanf("%d", &c);

  printf("\nEnter elements of 1st matrix:\n");
  for (i = 0; i < r; ++i)
    for (j = 0; j < c; ++j) {
      printf("Enter element a%d%d: ", i + 1, j + 1);
      scanf("%d", &a[i][j]);
    }

  printf("Enter elements of 2nd matrix:\n");
  for (i = 0; i < r; ++i)
    for (j = 0; j < c; ++j) {
      printf("Enter element b%d%d: ", i + 1, j + 1);
      scanf("%d", &b[i][j]);
    }

  // adding two matrices
  for (i = 0; i < r; ++i)
    for (j = 0; j < c; ++j) {
      sum[i][j] = a[i][j] + b[i][j];
    }

  // printing the result
  printf("\nSum of two matrices: \n");
  for (i = 0; i < r; ++i)
    for (j = 0; j < c; ++j) {
      printf("%d   ", sum[i][j]);
      if (j == c - 1) {
        printf("\n\n");
      }
    }
}


int main()
{
    int n, choice; // Number of disks
    char A,B,C;

    do
    {
        printf("\nEnter the choice\n");
        printf("\n1.Tower of Hanoi\n2.GCD Brute Force\n3.GCD Reccursion\n4.Addition of Matrix\n5.Exit\n");
        scanf("%d",&choice);

        switch(choice)
        {
            case 1:
                    printf("Enter the number of discs in tower\n");
                    scanf("%d",&n);
                    towerOfHanoi_261100690007(n, 'A', 'C', 'B');  // A, B and C are names of rods
                    //return 0;
                    break;

            case 2:
                    int num1, num2;
                    printf("Enter two positive integers: ");
                    if (scanf("%d %d", &num1, &num2) != 2) {
                        printf("Invalid input.\n");
                        return 1;
                    }
                    int brute_force_result = gcd_brute_force_261100690007(num1, num2);
                    printf("Brute-Force GCD of %d and %d is: %d\n", num1, num2, brute_force_result);
                    break;

            case 3:
                    int n1, n2;
                    printf("Enter two positive integers: ");
                    if (scanf("%d %d", &n1, &n2) != 2)
                    {
                        printf("Invalid input.\n");
                        return 1;
                    }
                    int recursive_result = gcd_recursive_261100690007(n1, n2);
                    printf("Recursion GCD of %d and %d is: %d\n", n1, n2, recursive_result);
                    break;

            case 4:
                    addition_of_matrix();
                    break;

            case 5:
                    printf("Exiting program...\n");
                    break;

            default:
                    printf("Invalid choice!\n");

        }
    }while (choice != 5);

    return 0;
}

